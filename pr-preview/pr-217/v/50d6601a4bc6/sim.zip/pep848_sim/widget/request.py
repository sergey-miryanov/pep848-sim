"""What a widget asks the simulator for: a workload, collector settings, a run length
and the records each part of a run holds, as JSON text, with the collector constants
and the real object's size where the playground changes them. A request can name a
preset in place of its workload and run length, so that a preset's numbers live in
one place, or carry the playground's Python source of all of them. The worker passes
the text on as the page sent it, so no browser object reaches the simulator.
"""

import json
from collections.abc import Collection, Iterator
from dataclasses import asdict, fields
from fractions import Fraction
from functools import lru_cache
from typing import Any, NamedTuple

from pep848_sim.collectors.collector import CollectorSettings, Constants, Record
from pep848_sim.collectors.incremental import IncrementalCollector
from pep848_sim.collectors.legacy import LegacyCollector
from pep848_sim.presets import PRESETS
from pep848_sim.run import run
from pep848_sim.structures import (
    Chains,
    Graph,
    Hierarchy,
    Own,
    Rings,
    Shape,
    StructureParameters,
    Tree,
)
from pep848_sim.widget import source
from pep848_sim.workload import ChurnParameters, WorkloadParameters


class Request(NamedTuple):
    workload: WorkloadParameters
    settings: CollectorSettings
    run_length: int
    every: int
    constants: Constants = Constants()


# The field a request may leave out, for its defaults.
_OPTIONAL = ("constants",)
# The fields of a request that names a preset, which brings its workload and run
# length.
_PRESET_FIELDS = ("preset", "settings", "every", *_OPTIONAL)
# The fields of a request that carries a workload source, which sets its
# workload, collector settings, run length and constants.
_SOURCE_FIELDS = ("source", "every")


# The worker reads each request four times, for its controls, its spelled-out
# form, its object graph and its runs. Keeping the last few runs a source and
# checks a shape of the reader's own once for all four, and each reading gets the
# same workload, whatever the source draws.
@lru_cache(maxsize=16)
def parse(request: str) -> Request:
    """The request a widget sends, refused unless it holds every field but the
    constants, and no other."""
    values = json.loads(request)
    if "source" in values:
        values = _values(values, _SOURCE_FIELDS, "request")
        workload, settings, run_length, constants = source.read(values["source"])
        for structure in workload.structures:
            _check(structure)
        return Request(
            workload, _checked(settings), run_length, values["every"], constants
        )
    if "preset" in values:
        values = _values(values, _PRESET_FIELDS, "request", _OPTIONAL)
        preset = PRESETS.get(values["preset"])
        if preset is None:
            raise ValueError(f"no preset {values['preset']!r}")
        return Request(
            preset.workload,
            _settings(values["settings"]),
            preset.run_length,
            values["every"],
            _constants(values),
        )
    values = _values(values, Request._fields, "request", _OPTIONAL)
    return Request(
        _workload(values["workload"]),
        _settings(values["settings"]),
        values["run_length"],
        values["every"],
        _constants(values),
    )


def expand(request: str) -> str:
    """The request with any preset it names spelled out: the preset's workload and
    run length, which the widget's controls then edit, and the constants."""
    return dump(parse(request))


def dump(request: Request) -> str:
    """A request as JSON text, as `parse` reads it."""
    workload = request.workload
    churn = workload.churn
    return json.dumps(
        {
            "workload": {
                "churn": asdict(churn)
                | {
                    "cycle_share": str(churn.cycle_share),
                    "long_share": str(churn.long_share),
                    "long_lifetimes": list(churn.long_lifetimes),
                },
                "structures": [
                    asdict(structure) | {"shape": _named(structure.shape)}
                    for structure in workload.structures
                ],
                "seed": workload.seed,
                "shutdown": workload.shutdown,
            },
            "settings": asdict(request.settings),
            "run_length": request.run_length,
            "every": request.every,
            "constants": asdict(request.constants)
            | {"long_lived_ratio": str(request.constants.long_lived_ratio)},
        }
    )


def runs(request: str) -> tuple[Iterator[list[Record]], Iterator[list[Record]]]:
    """The two runs a widget compares, legacy first."""
    workload, settings, run_length, every, constants = parse(request)
    return (
        run(workload, LegacyCollector, settings, run_length, every, constants),
        run(workload, IncrementalCollector, settings, run_length, every, constants),
    )


def _names(parameters: type) -> list[str]:
    return [field.name for field in fields(parameters)]


def _settings(values: dict[str, Any]) -> CollectorSettings:
    return _checked(
        CollectorSettings(**_values(values, _names(CollectorSettings), "settings"))
    )


def _constants(values: dict[str, Any]) -> Constants:
    """The constants a request holds, or the defaults where it holds none."""
    if "constants" not in values:
        return Constants()
    constants = _values(values["constants"], _names(Constants), "constants")
    return Constants(
        **constants | {"long_lived_ratio": Fraction(constants["long_lived_ratio"])}
    )


def _checked(settings: CollectorSettings) -> CollectorSettings:
    # The legacy collector takes a threshold1 of 0, but the incremental collector
    # counts its aging spaces from it, and a widget runs both.
    if settings.threshold1 < 1:
        raise ValueError(
            f"a threshold1 of {settings.threshold1} leaves the incremental collector"
            " no aging space"
        )
    return settings


def _values(
    values: dict[str, Any],
    names: Collection[str],
    what: str,
    optional: Collection[str] = (),
) -> dict[str, Any]:
    """The values of `what`, which holds each field named but the optional ones,
    and no other."""
    for name in values:
        if name not in names:
            raise ValueError(f"{what} has no field {name!r}")
    for name in names:
        if name not in values and name not in optional:
            raise ValueError(f"{what} lacks {name!r}")
    return values


def _workload(values: dict[str, Any]) -> WorkloadParameters:
    values = _values(values, _names(WorkloadParameters), "workload")
    churn = _values(values["churn"], _names(ChurnParameters), "churn")
    return WorkloadParameters(
        ChurnParameters(
            **churn
            | {
                "cycle_share": Fraction(churn["cycle_share"]),
                "long_share": Fraction(churn["long_share"]),
                "long_lifetimes": tuple(churn["long_lifetimes"]),
            }
        ),
        tuple(_structure(structure) for structure in values["structures"]),
        values["seed"],
        values["shutdown"],
    )


def _structure(values: dict[str, Any]) -> StructureParameters:
    # Links the playground wrote before a frame could build a structure leave
    # built_in_frame out.
    values = _values(
        values, _names(StructureParameters), "structure", optional=["built_in_frame"]
    )
    return _check(StructureParameters(**values | {"shape": _shape(values["shape"])}))


def _check(structure: StructureParameters) -> StructureParameters:
    # A reader's own links show their faults before a run starts.
    if isinstance(structure.shape, Own):
        structure.shape.check(structure.size)
    return structure


def _named(shape: Shape) -> str | dict[str, int] | dict[str, str]:
    """A shape as a request names it."""
    if isinstance(shape, Tree):
        return "tree"
    if isinstance(shape, Chains):
        return {"chains": shape.width}
    if isinstance(shape, Hierarchy):
        return {"hierarchy": shape.branches}
    if isinstance(shape, Graph):
        return {"graph": shape.edges}
    if isinstance(shape, Own):
        return {"own": shape.code}
    return {"rings": shape.length}


def _shape(shape: Any) -> Shape:
    """A shape: "tree", {"chains": width}, {"hierarchy": branches},
    {"graph": edges}, {"rings": length}, or {"own": code} for the reader's own."""
    if shape == "tree":
        return Tree()
    if isinstance(shape, dict) and list(shape) == ["chains"]:
        return Chains(shape["chains"])
    if isinstance(shape, dict) and list(shape) == ["hierarchy"]:
        return Hierarchy(shape["hierarchy"])
    if isinstance(shape, dict) and list(shape) == ["graph"]:
        return Graph(shape["graph"])
    if isinstance(shape, dict) and list(shape) == ["rings"]:
        return Rings(shape["rings"])
    if isinstance(shape, dict) and list(shape) == ["own"]:
        if not isinstance(shape["own"], str):
            raise ValueError("your shape's code is not text")
        return Own(shape["own"])
    raise ValueError(f"no shape {shape!r}")
